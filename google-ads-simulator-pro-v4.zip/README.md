# Google Ads Simulator Pro v3

Independent educational simulator. Not affiliated with Google. No real ads, no real money, no API calls.

## Run
Unzip and open `index.html` in Chrome, Edge or Firefox. No server or install needed.

## Folder structure
```
index.html            app shell (scripts load with defer)
css/
  style.css           base styles
  animations.css      page, chart, table and button animations (respects reduced motion)
  tools.css           sidebar groups, ad lab, tool layouts
js/
  core/               data.js, presets.js, store.js, engine.js (no DOM)
  ui/                 charts.js, views.js, wizard.js, fx.js (animations, auto-run), app.js (router)
  tools/              tools.js (ad lab, keyword planner, calculators, negatives)
data/                 sample-account.json (Tools > Import)
docs/                 FEATURES.md, CHANGELOG.md
assets/               favicon
```

## What's new in v3
- Animations: page transitions, count-up numbers, line and sparkline drawing, growing bars, live-status glow, rotating ad headlines
- Auto-run: advance the simulation a day every 1.2 s from the top bar
- Tools hub with 5 tools: Ad preview lab (mobile/desktop), intent-based Keyword planner, Budget calculator, Break-even calculator, Negative keywords (apply to a campaign)
- Keyword planner: intent groups, opportunity score, 12-month trend, suggested match types, one-click send to new campaign
- Dashboard KPIs show change vs the previous period; button ripples, step transitions, auto-run progress bar
- Sidebar grouped into Workspace, Tools, Account
- Performance: memoised totals, debounced saving, 120-day history cap, deferred scripts, no scroll jump on actions

## Deploy (GitHub + Vercel)
This is a static site: no build step. `index.html` must be at the **repo root**.
```
cd google-ads-simulator-pro      # the folder that contains index.html
git init && git add . && git commit -m "Ads Simulator Pro v3"
git branch -M main
git remote add origin https://github.com/<user>/<repo>.git
git push -u origin main
```
Vercel: Add New > Project > import the repo. Framework Preset: **Other**, Build Command: empty, Output Directory: `.` (or leave default), then Deploy.
