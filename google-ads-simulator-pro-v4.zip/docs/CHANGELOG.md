# Changelog
## v3.1
- Removed UTM builder; smarter keyword planner; period-over-period KPIs; more animations
## v3
- Reorganised into css/, js/core, js/ui, js/tools
- Added animations.css, fx.js, tools.js, presets.js
- Storage schema unchanged (`gasim.v2`), so existing saved data and exports still work
## v2
- Daily simulation, wizard validation, recommendations, reports, billing
