# Feature notes
- **Ad strength (0-100)**: headline count, descriptions, keyword/headline relevance, unique headlines, sitelinks and callouts. Quality score = 2 + strength/14 (1-10).
- **Daily simulation**: cost = daily budget x pace x weekday factor; CPC falls and CTR rises as quality score rises. Deterministic (seeded), so results are repeatable.
- **Recommendations**: re-enable strong paused campaigns, raise budget when budget-limited, improve assets, add negatives, fix low CTR / high CPA.
- **Storage**: key `gasim.v2` in localStorage. Export JSON for backups.
