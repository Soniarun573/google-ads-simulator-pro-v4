(function(){const GA=window.GA=window.GA||{};
GA.presets={negatives:{'General':['free','jobs','salary','cheap','diy','pdf','torrent'],'Retail / E-commerce':['wholesale','second hand','repair','manual','used','complaint','refund'],'Local services':['jobs','training','tutorial','school','franchise','how to'],'Education / Coaching':['free','pdf','previous year','answer key','youtube','jobs'],'Travel & Rentals':['driver job','insurance claim','accident','licence test','free']}};
})();
