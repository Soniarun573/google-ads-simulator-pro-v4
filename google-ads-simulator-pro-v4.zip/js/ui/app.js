(function(){const GA=window.GA,$=s=>document.querySelector(s);
GA.route=anim=>{const h=location.hash.replace(/^#\/?/,'')||'campaigns',[p,a]=h.split('/');const v=GA.views[p]||GA.views.campaigns,pg=['c','new','edit'].includes(p)?'campaigns':p==='tool'?'tool/'+a:p;
document.querySelectorAll('aside .nav').forEach(n=>n.classList.toggle('active',n.dataset.page===pg));GA.fx.before();try{v(a)}catch(e){console.error(e);$('#app').innerHTML='<div class="alert err">Something went wrong: '+GA.esc(e.message)+'</div>'}GA.refreshTop();if(anim===true)window.scrollTo(0,0);GA.fx.after(anim===true)};
const redraw=()=>{GA.save();GA.route()};
const A={...GA.actions,toggle:d=>{const c=GA.get(d.id);c.status=c.status==='Paused'?'Enabled':'Paused';redraw();GA.toast(c.name+': '+c.status)},
del:d=>{if(confirm('Delete this campaign?')){GA.S.campaigns=GA.S.campaigns.filter(c=>c.id!==+d.id);redraw()}},
clone:d=>{const c=GA.clone(GA.get(d.id));c.id=GA.S.nextId++;c.name+=' (copy)';c.cfg.campaignName=c.name;c.status='Paused';c.days=c.days.map(x=>({d:x.d,imp:0,clk:0,cost:0,conv:0}));GA.S.campaigns.unshift(c);redraw();GA.toast('Campaign cloned')},
adv:d=>{GA.advance(+d.n);GA.route();GA.toast('Advanced '+d.n+' day(s)')},
rec:d=>{const r=GA.recs().find(x=>x.k===d.k);if(r){GA.applyRec(r);if(!/edit/.test(location.hash)){GA.route();GA.toast('Recommendation applied')}}},
dismiss:d=>{GA.S.dismissed.push(d.k);redraw()},
csv:()=>{const rows=['date,campaign,type,impressions,clicks,cost,conversions'];GA.S.campaigns.forEach(c=>c.days.slice(-GA.S.range).forEach(x=>rows.push([x.d,'"'+c.name.replace(/"/g,'""')+'"',c.type,x.imp,x.clk,x.cost,x.conv].join(','))));GA.dl('ads-simulator-report.csv',rows.join('\n'),'text/csv')},
exp:()=>GA.dl('ads-simulator-account.json',JSON.stringify(GA.S,null,1),'application/json'),
reset:()=>{if(confirm('Reset all data to the demo account?')){GA.reset();GA.route();GA.toast('Demo data restored')}},
pick:d=>GA.W.pick(d.k,d.v),go:d=>GA.W.go(+d.n),next:()=>GA.W.next(),back:()=>GA.W.back(),discard:()=>GA.W.discard(),finish:d=>GA.W.finish(d.en==='1')};
document.addEventListener('click',e=>{const t=e.target.closest('[data-act]');if(t&&A[t.dataset.act]){e.preventDefault();A[t.dataset.act](t.dataset);return}
const th=e.target.closest('th[data-sort]');if(th){const k=th.dataset.sort;GA.ui.dir=GA.ui.sort===k?-GA.ui.dir:-1;GA.ui.sort=k;$('#tbl').innerHTML=GA.table()}});
document.addEventListener('input',e=>{const el=e.target;if(el.dataset.key)GA.W.input(el);else if(el.id==='q'){GA.ui.q=el.value;$('#tbl').innerHTML=GA.table()}else if('calc' in el.dataset&&GA.calcs[el.dataset.calc])GA.calcs[el.dataset.calc]()});
document.addEventListener('change',e=>{const el=e.target;if(el.dataset.check)GA.W.check(el);else if(el.dataset.key&&el.tagName==='SELECT'){GA.W.input(el);if(['bid','budgetType'].includes(el.dataset.key))GA.wizard()}
else if(el.id==='labc'){GA.ui.lab=el.value;GA.route()}else if(el.classList.contains('negc'))GA.calcs.neg();else if(el.id==='st'){GA.ui.st=el.value;$('#tbl').innerHTML=GA.table()}else if(el.id==='rng'){GA.S.range=+el.value;redraw()}else if(el.id==='metric'){GA.ui.metric=el.value;GA.route()}
else if(el.id==='imp'&&el.files[0]){const r=new FileReader();r.onload=()=>{try{GA.importJSON(r.result);GA.route();GA.toast('Imported')}catch(x){GA.toast('Import failed: '+x.message)}};r.readAsText(el.files[0])}});
window.addEventListener('hashchange',()=>GA.route(true));GA.load();GA.route(true);
})();
